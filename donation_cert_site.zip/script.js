function generateCertificate() {
  const name = document.getElementById("donorName").value || "ผู้มีจิตศรัทธา";
  const date = document.getElementById("donateDate").value || new Date().toLocaleDateString("th-TH");

  document.getElementById("nameArea").innerText = name;
  document.getElementById("dateArea").innerText = new Date(date).toLocaleDateString("th-TH", {
    year: "numeric", month: "long", day: "numeric"
  });

  document.getElementById("certificate").style.display = "block";
}

function downloadImage() {
  html2canvas(document.getElementById("certificate")).then(canvas => {
    const link = document.createElement("a");
    link.download = "ใบอนุโมทนาบัตร.png";
    link.href = canvas.toDataURL();
    link.click();
  });
}
